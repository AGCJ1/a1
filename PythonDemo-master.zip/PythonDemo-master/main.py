import ujson
import time
import MQTT
import machine

print('***************adding from pythonA')
print('**************this is a demo ******************')
print('**************adding by pythonB****************')
print('**************master adding ******************')
print('**************adding now*******************')
print('**************adding from master branch')
print('**************adding from pythonD branch*************')
print('***************adding at 2019-6-4-8:08')
print('***************adding at 2019-6-4-9:22')
print('***************adding at 2019-6-5-8:15')


